Dear <?php echo e($data->task_owner); ?>,

The task "<?php echo e($data->task_description); ?>" has been added for you.<br><br>

<?php if($data->status == 0): ?>
Kindly complete it within <?php echo e($data->task_eta); ?>.<br><br>
<?php else: ?>
It has been marked as completed.<br><br>
<?php endif; ?>

Thank you.
<?php /**PATH C:\xampp\htdocs\major\task_manager\resources\views/email/notification.blade.php ENDPATH**/ ?>